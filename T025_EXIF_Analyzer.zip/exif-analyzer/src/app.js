const express = require('express');
const multer = require('multer');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const { extractMetadata } = require('./exifReader');

const app = express();
const PORT = process.env.PORT || 3002;

// Multer config for image uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = path.join(__dirname, '..', 'uploads');
    if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + '-' + file.originalname);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 20 * 1024 * 1024 }, // 20MB max
  fileFilter: (req, file, cb) => {
    const allowed = /jpeg|jpg|png|gif|tiff|tif|webp|heic|heif|bmp/;
    const ext = path.extname(file.originalname).toLowerCase().replace('.', '');
    if (allowed.test(ext)) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed (JPEG, PNG, TIFF, HEIC, WebP)'));
    }
  }
});

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

// POST /upload — Upload and analyze image
app.post('/upload', upload.single('image'), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No image file uploaded' });
  }

  try {
    console.log(`📸 Analyzing: ${req.file.originalname} (${(req.file.size / 1024).toFixed(1)} KB)`);

    const result = await extractMetadata(req.file.path);

    // Add file info
    result.file = {
      name: req.file.originalname,
      size: req.file.size,
      sizeFormatted: formatFileSize(req.file.size),
      type: req.file.mimetype
    };

    // Delete uploaded file for privacy
    fs.unlink(req.file.path, (err) => {
      if (err) console.warn('Could not delete temp file:', err.message);
    });

    res.json(result);
  } catch (err) {
    // Clean up on error
    if (req.file && req.file.path) {
      fs.unlink(req.file.path, () => {});
    }
    res.status(500).json({ error: 'Failed to analyze image: ' + err.message });
  }
});

function formatFileSize(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
}

// Serve frontend
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`\n📷 EXIF Metadata Analyzer running at http://localhost:${PORT}\n`);
});
