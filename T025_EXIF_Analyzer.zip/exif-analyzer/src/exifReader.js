const exifr = require('exifr');

/**
 * Extract EXIF metadata from an image file
 * @param {string} filePath - Path to the image file
 * @returns {object} Parsed metadata
 */
async function extractMetadata(filePath) {
  try {
    // Parse all available EXIF data
    const allData = await exifr.parse(filePath, {
      tiff: true,
      xmp: true,
      icc: true,
      iptc: true,
      gps: true,
      interop: true,
      translateKeys: true,
      translateValues: true,
      reviveValues: true,
    });

    if (!allData) {
      return { success: false, message: 'No EXIF data found in this image.' };
    }

    // Extract GPS separately for better accuracy
    const gps = await exifr.gps(filePath).catch(() => null);

    // Build structured result
    const result = {
      success: true,
      device: {},
      photo: {},
      gps: null,
      software: null,
      datetime: null,
      raw: {}
    };

    // Device info
    if (allData.Make) result.device.make = allData.Make;
    if (allData.Model) result.device.model = allData.Model;
    if (allData.LensModel) result.device.lens = allData.LensModel;
    if (allData.LensMake) result.device.lensMake = allData.LensMake;

    // Photo settings
    if (allData.ExposureTime) {
      const expo = allData.ExposureTime;
      result.photo.exposureTime = expo < 1 ? `1/${Math.round(1/expo)}s` : `${expo}s`;
    }
    if (allData.FNumber) result.photo.aperture = `f/${allData.FNumber}`;
    if (allData.ISO || allData.ISOSpeedRatings) result.photo.iso = allData.ISO || allData.ISOSpeedRatings;
    if (allData.FocalLength) result.photo.focalLength = `${allData.FocalLength}mm`;
    if (allData.Flash !== undefined) result.photo.flash = allData.Flash;
    if (allData.WhiteBalance) result.photo.whiteBalance = allData.WhiteBalance;
    if (allData.ExposureMode) result.photo.exposureMode = allData.ExposureMode;
    if (allData.MeteringMode) result.photo.meteringMode = allData.MeteringMode;
    if (allData.ImageWidth) result.photo.width = allData.ImageWidth;
    if (allData.ImageHeight) result.photo.height = allData.ImageHeight;
    if (allData.ExifImageWidth) result.photo.width = result.photo.width || allData.ExifImageWidth;
    if (allData.ExifImageHeight) result.photo.height = result.photo.height || allData.ExifImageHeight;
    if (allData.ColorSpace) result.photo.colorSpace = allData.ColorSpace;
    if (allData.Orientation) result.photo.orientation = allData.Orientation;

    // GPS
    if (gps && gps.latitude && gps.longitude) {
      result.gps = {
        latitude: Math.round(gps.latitude * 1000000) / 1000000,
        longitude: Math.round(gps.longitude * 1000000) / 1000000,
        mapUrl: `https://maps.google.com/?q=${gps.latitude},${gps.longitude}`
      };
      if (allData.GPSAltitude) result.gps.altitude = `${Math.round(allData.GPSAltitude)}m`;
    }

    // Software
    if (allData.Software) result.software = allData.Software;
    if (allData.Creator) result.software = result.software || allData.Creator;

    // Date/Time
    if (allData.DateTimeOriginal) {
      result.datetime = allData.DateTimeOriginal;
    } else if (allData.CreateDate) {
      result.datetime = allData.CreateDate;
    } else if (allData.ModifyDate) {
      result.datetime = allData.ModifyDate;
    }

    // Copyright & Author
    if (allData.Copyright) result.copyright = allData.Copyright;
    if (allData.Artist) result.artist = allData.Artist;

    // Raw data (filtered to interesting keys)
    const skipKeys = ['MakerNote', 'UserComment', 'undefined', 'ApplicationNotes'];
    for (const [key, value] of Object.entries(allData)) {
      if (!skipKeys.includes(key) && value !== undefined && value !== null) {
        if (typeof value !== 'object' || value instanceof Date) {
          result.raw[key] = value;
        }
      }
    }

    return result;
  } catch (err) {
    console.error('EXIF extraction error:', err.message);
    return { success: false, message: 'Failed to extract EXIF data: ' + err.message };
  }
}

module.exports = { extractMetadata };
